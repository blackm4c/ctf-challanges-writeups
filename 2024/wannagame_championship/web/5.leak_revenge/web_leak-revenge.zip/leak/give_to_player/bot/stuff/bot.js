#!/usr/bin/env node
const puppeteer = require('puppeteer')
const util = require('util');
const dns = require('dns');
const lookup = util.promisify(dns.lookup);
const { exit } = require('process');

const SECRET_TOKEN = process.env.SECRET_TOKEN;
const webDomain = process.env.WEB_DOMAIN ?? (console.log("no WEB_DOMAIN env"),exit(1));

async function visit(url){
	let browser;

	if(!url.startsWith("http://") && !url.startsWith("https://")){
		return;
	}

	if (!SECRET_TOKEN) {
		console.log("NO SECRET_TOKEN provided")
		process.exit(1)
	}

	try{
		browser = await puppeteer.launch({
		    pipe: true,
		    args: [
		        "--no-sandbox",
		        "--disable-setuid-sandbox",
		        "--js-flags=--noexpose_wasm,--jitless",
		        "--ignore-certificate-errors"
		    ],
		    executablePath: "/usr/bin/google-chrome-stable",
		    headless: 'new'
		});

		let page = await browser.newPage();
		const {address:ip} = await lookup(webDomain)

		await page.setCookie({
			httpOnly: true,
			secure: false,
			name: 'SECRET_TOKEN',
			value: SECRET_TOKEN,
			domain: ip,
			sameSite: 'Lax'
		});

		page = await browser.newPage();
		await page.goto(url,{ waitUntil: 'domcontentloaded', timeout: 2000 });
		await new Promise(r=>setTimeout(r, 120000));
	}catch(e){ console.log(e) }
	try{await browser.close();}catch(e){}
	process.exit(0)
}

visit(JSON.parse(process.argv[2]))
